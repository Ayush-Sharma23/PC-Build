import mysql.connector

myconnection = mysql.connector.connect(host = 'localhost' , user = 'root' , passwd = '1234' , database = 'comp_builder')
mycursor = myconnection.cursor()

# CREATING TABLE
mycursor.execute('create table main(sr_no int(4) , processor varchar(99) , GPU varchar(99),PSU varchar(10) , RAM varchar(10) , ROM varchar(10) , Budget(10) , USE_case(20));')
mycursor.commit()

#INSERTING VALUES IN TABLE
mycursor.execute('Insert into main (sr_no , processor) Values(1 , "i3") , (2 , "i3"),(3,"i3"),(4,"i5"),(6,"i5");')
mycursor.commit()
mycursor.execute('Insert into main (GPU , PSU) Values("None" , "300w") , ("NONE" , "330w"),("rtx780","500w"),("rtx1650","550w"),("rtx1660s","600w");')
mycursor.commit()
mycursor.execute('Insert into main (RAM,ROM) Values("4GB" , "1TB HDD") , ("8GB" , "1TB HDD"),("8GB","512 SSD"),("16GB","512 SSD"),("16GB","512 SSD");')
mycursor.commit()
mycursor.execute('Insert into main (Budget , USE_case) Values("20000" , "office") , ("25000" , "office"),("35000","gaming"),("45000","gaming"),("50000","gaming");')
mycursor.commit()
