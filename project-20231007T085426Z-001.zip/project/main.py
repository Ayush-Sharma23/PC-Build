import tkinter as tk
from PIL import Image,ImageTk
import mysql.connector

myconnection = mysql.connector.connect(host = 'localhost' , user = 'root' , passwd = '1234', database = 'comp_builder')
mycursor = myconnection.cursor()
myconnection.autocommit = True


#mainloop
root = tk.Tk()
#TITLE
root.title('PC Builder')

canvas = tk.Canvas(root , width = 600 , height = 300 , bg = 'white')
canvas.grid(columnspan=3 , rowspan=5)

#logo
logo = Image.open('logo.png')
logo = ImageTk.PhotoImage(logo)
logo_label = tk.Label(image=logo)
logo_label.image = logo
logo_label.grid(column = 1 , row =0)


#instructions
instructions = tk.Label(root , text = "Select your budget and use case :", font = 'raleway')
instructions.grid(columnspan=3 , column = 0 , row = 1)

#buttons
options =['20000' ,'25000','35000','45000','50000','60000','70000','90000']

def datareturn(selected_budget , selected_usage):
    list = []
    mycursor.execute(f"SELECT * FROM main where Budget>={selected_budget} And USE_case like '{selected_usage}';")
    answer = mycursor.fetchall()
    for i in answer:
        list.append(i)


    return list

def collect():
    global text1
    selected_budget = budget_text.get()
    selected_usage = use_text.get()
    print(selected_budget , selected_usage)
    instructions.destroy()
    budget_menu.destroy()
    use_btn.destroy()

    b= list(datareturn(selected_budget, selected_usage))
    headings = tk.Label(root ,text = 'sr_no , processor ,Motherboard ,GPU , PSU ,Cabinet, RAM, ROM,USE_Case , Budget')
    headings.grid(column = 1 , row = 1)
    show_text= tk.StringVar()
    show_label = tk.OptionMenu(root ,show_text, *b )
    show_text.set('options')
    show_label.grid(column = 1 , row = 2)

#budget drop-down list
budget_text = tk.StringVar()
budget_menu = tk.OptionMenu(root ,budget_text , *options )
budget_text.set("Budget")
budget_menu.grid(column=1 , row = 2)

#use case drop_down list
use_cases = ['office' , 'gaming' , 'creative']
use_text = tk.StringVar()
use_btn = tk.OptionMenu(root ,use_text , *use_cases )
use_text.set("Use Case")
use_btn.grid(column=1 , row = 3)

save_btn = tk.Button(root , text = "Save" , command= collect, bg = "#20bebe" , fg = "white")
save_btn.grid(column = 1  , row=4)


canvas = tk.Canvas(root , width = 600 , height = 250 , bg = 'white' )
canvas.grid(columnspan=3)

root.mainloop()
